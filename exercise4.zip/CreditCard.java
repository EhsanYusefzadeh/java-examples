

public class CreditCard {
    private String cardNumber;
    private double credit;


    // setters and getters
    public String getCardNumber() {
        return cardNumber;
    }

    public double getCredit() {
        return credit;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }
}
