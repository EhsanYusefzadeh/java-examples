package ir.javacup.paint;

public class Circle extends Shape {
    Double redius;

    public Circle(Color c, Pattern p, double r) {
        super(c, p);
        this.redius = r;
    }


    public String toString() {
        String stringToReturn = String.format("\t\n" +
                "Circle[color:%s, pattern:%s, redius:%.0f]", this.color, this.pattern, this.redius);
        return stringToReturn;
    }


    public boolean equals(Circle crl){
        if(crl == null)
            return false;

        if(redius.equals(crl.redius) && this.color == crl.color && this.pattern == crl.pattern){
            return true;
        }else{
            return false;
        }
    }
}